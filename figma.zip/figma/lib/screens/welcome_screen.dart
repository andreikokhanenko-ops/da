import 'package:flutter/material.dart';

/// Макет 2 (простой): экран входа «medinow».
/// Цвет фона чуть сдвинут от циана к мятному.
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  static const Color bg = Color(0xFF3DE3D3);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 30),
            const Text(
              'medinow',
              style: TextStyle(
                fontSize: 38,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 6),
            const Text('Meditate With Us!',
                style: TextStyle(fontSize: 16, color: Colors.white)),
            const SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  _PillButton(
                    text: 'Sign in with Apple',
                    color: Colors.white,
                    icon: Icons.apple,
                    onTap: () => _snack(context, 'Вход через Apple'),
                  ),
                  const SizedBox(height: 12),
                  _PillButton(
                    text: 'Continue with Email or Phone',
                    color: const Color(0xFFDDFFFA),
                    onTap: () => _snack(context, 'Вход по e-mail'),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () => _snack(context, 'Вход через Google'),
                    child: const Text('Continue With Google',
                        style: TextStyle(color: Colors.white, fontSize: 14)),
                  ),
                ],
              ),
            ),
            const Spacer(),
            const _MeditatingPerson(),
          ],
        ),
      ),
    );
  }

  void _snack(BuildContext context, String text) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(text)));
  }
}

class _PillButton extends StatelessWidget {
  const _PillButton({
    required this.text,
    required this.color,
    required this.onTap,
    this.icon,
  });

  final String text;
  final Color color;
  final IconData? icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.black,
          elevation: 0,
          shape: const StadiumBorder(),
        ),
        onPressed: onTap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 20),
              const SizedBox(width: 8),
            ],
            Text(text, style: const TextStyle(fontSize: 15)),
          ],
        ),
      ),
    );
  }
}

/// Иллюстрация медитирующего человека среди листьев.
class _MeditatingPerson extends StatelessWidget {
  const _MeditatingPerson();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 280,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          // тень-платформа
          Positioned(
            bottom: 20,
            child: Container(
              width: 260,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF22B3A6),
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
          const Positioned(
              left: 30,
              bottom: 60,
              child: Icon(Icons.eco, size: 110, color: Color(0xFF7FF0E6))),
          const Positioned(
              right: 30,
              bottom: 70,
              child: Icon(Icons.spa, size: 120, color: Color(0xFF7FF0E6))),
          const Positioned(
            bottom: 36,
            child: Icon(Icons.self_improvement,
                size: 190, color: Color(0xFF1E3345)),
          ),
        ],
      ),
    );
  }
}
