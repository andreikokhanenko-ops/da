import 'package:flutter/material.dart';

import 'screens/meditation_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/course_screen.dart';
import 'screens/wallet_screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Макеты из Figma',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF6A4CFF),
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const HomeMenu(),
    );
  }
}

/// Главное меню: из него открывается каждый из четырёх макетов.
class HomeMenu extends StatelessWidget {
  const HomeMenu({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_MenuItem>[
      _MenuItem('1. Mind Deep Relax', 'Простой макет', Icons.self_improvement,
          const MeditationScreen()),
      _MenuItem('2. Medinow — вход', 'Простой макет', Icons.login,
          const WelcomeScreen()),
      _MenuItem('3. 3D Design Basic', 'Сложный макет', Icons.school_outlined,
          const CourseScreen()),
      _MenuItem('4. My E-Wallet', 'Сложный макет',
          Icons.account_balance_wallet_outlined, const WalletScreen()),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Макеты из Figma')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final item = items[i];
          return Card(
            child: ListTile(
              leading: Icon(item.icon, size: 30),
              title: Text(item.title,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(item.subtitle),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => item.screen),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _MenuItem {
  _MenuItem(this.title, this.subtitle, this.icon, this.screen);
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget screen;
}
